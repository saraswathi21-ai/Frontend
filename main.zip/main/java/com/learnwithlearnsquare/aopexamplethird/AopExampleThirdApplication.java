package com.learnwithlearnsquare.aopexamplethird;
import com.learnwithlearnsquare.aopexamplethird.service.MyService;
import com.learnwithlearnsquare.aopexamplethird.exception.MyCustomException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
// @EnableAspectJAutoProxy is often not explicitly needed with Spring Boot
// as it's enabled by default when spring-boot-starter-aop is on the classpath.
// However, it's good practice to include it for clarity or if you encounter issues.
@EnableAspectJAutoProxy(proxyTargetClass = true) // proxyTargetClass = true ensures CGLIB proxies are used, allowing advice on concrete classes
public class AopExampleThirdApplication implements CommandLineRunner {

    private final MyService myService;

    // Inject MyService into the main application class
    public AopExampleThirdApplication(MyService myService) {
        this.myService = myService;
    }

    public static void main(String[] args) {
        SpringApplication.run(AopExampleThirdApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n--- Calling service methods ---");
        myService.doSomething();
        myService.doSomethingWithArgs("Hello AOP", 123);

        try {
            myService.doSomethingThatThrowsException();
        } catch (MyCustomException e) {
            System.out.println("Caught expected exception in main app: " + e.getMessage());
        }

        System.out.println("--- Service method calls finished ---\n");
    }
}
