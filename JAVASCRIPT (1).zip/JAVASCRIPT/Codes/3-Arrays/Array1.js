const myArray = ['h', 'e', 'l', 'l', 'o'];

console.log(myArray[0]);  //First element

console.log(myArray[1]); //Second element