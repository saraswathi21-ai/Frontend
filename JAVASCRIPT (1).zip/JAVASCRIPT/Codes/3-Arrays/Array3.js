let dailyActivities = ['eat', 'sleep'];

dailyActivities.unshift('work'); //Add an element at the start

console.log(dailyActivities); 	 //['work', 'eat', 'sleep']