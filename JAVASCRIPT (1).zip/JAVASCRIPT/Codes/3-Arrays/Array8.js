let dailyActivities = ['work', 'eat', 'sleep'];

dailyActivities.shift();		//Remove the first element

console.log(dailyActivities); 