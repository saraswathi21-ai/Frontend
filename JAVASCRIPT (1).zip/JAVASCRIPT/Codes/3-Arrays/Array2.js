let dailyActivities = ['eat', 'sleep'];

dailyActivities.push('exercise');  //Add an element at the end

console.log(dailyActivities); 	   //['eat', 'sleep', 'exercise']