const dailyActivities = ['eat', 'sleep'];

console.log(dailyActivities.length); //Total number of elements in an array