let dailyActivities = ['eat', 'sleep'];

dailyActivities[3] = 'exercise';  //Add the new element at the 3 index

console.log(dailyActivities);   