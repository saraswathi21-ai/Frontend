function add(a, b)
{
    console.log(a + b);
}
//calling functions
add(3,4);
add(2,9);