var n1 = 10;
var n2 = 20;
var sum = n1 + n2;
console.log("Sum of "+n1+" and "+n2+" is : "+sum);
