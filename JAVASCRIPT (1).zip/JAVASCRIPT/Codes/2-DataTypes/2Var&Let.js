var a;
console.log(a);
var a = 5;

let b;
console.log(b);
let b = 5;
