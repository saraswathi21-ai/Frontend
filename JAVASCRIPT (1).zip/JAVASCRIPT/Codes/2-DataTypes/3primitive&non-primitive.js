var str1 = "Primitive";
var str2 = new String('Non Primitive');  //String object
console.log(str1+" "+str2);
